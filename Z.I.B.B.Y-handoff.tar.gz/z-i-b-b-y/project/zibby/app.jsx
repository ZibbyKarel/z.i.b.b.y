// ZIBBY velín — top-level app: shell + screen router
const { useState: useStateApp } = React;

// graceful placeholder for not-yet-built screens
const Placeholder = ({ nav, accent }) => (
  <div style={{ maxWidth: 1400, margin: '0 auto' }}>
    <HudPanel accent={accent} pad={40}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, padding: '40px 0', textAlign: 'center' }}>
        <div style={{ width: 54, height: 54, borderRadius: 3, display: 'grid', placeItems: 'center', color: accent, border: `1px solid ${accent}55`, background: 'rgba(255,255,255,0.02)' }}>
          <Icon name={(NAV.find((n) => n.id === nav) || {}).glyph || (nav === 'settings' ? 'gear' : 'grid')} size={26} />
        </div>
        <div style={{ fontSize: 20, fontWeight: 600 }}>{NAV_LABEL[nav]}</div>
        <Mono style={{ fontSize: 12, color: Z.inkDim, maxWidth: 420, lineHeight: 1.5 }}>
          Tahle obrazovka je další na řadě. Drží stejný vzor — karty (= soubory na disku) → čudlík → modal s promptem → běh na pozadí.
        </Mono>
        <Mono style={{ fontSize: 10, color: Z.inkFaint, letterSpacing: '0.1em' }}>// v přípravě</Mono>
      </div>
    </HudPanel>
  </div>
);

function App() {
  const loadSettings = () => {
    const def = { lang: 'cs', defaultCtx: 'home', caffeinate: true };
    try { return { ...def, ...JSON.parse(localStorage.getItem('zibby.settings') || '{}') }; } catch (e) { return def; }
  };
  const [settings, setSettings] = useStateApp(loadSettings);
  const saveSettings = (patch) => setSettings((prev) => {
    const next = { ...prev, ...patch };
    try { localStorage.setItem('zibby.settings', JSON.stringify(next)); } catch (e) {}
    return next;
  });

  const [nav, setNav] = useStateApp('overview');
  const [skills, setSkills] = useStateApp(SKILLS);
  const [agents, setAgents] = useStateApp(AGENTS);
  const [skillCats, setSkillCats] = useStateApp(SKILL_CATEGORIES);
  const [agentCats, setAgentCats] = useStateApp(AGENT_CATEGORIES);
  const [gateRules, setGateRules] = useStateApp(GLOBAL_RULES);
  const [gateRuleCats, setGateRuleCats] = useStateApp(GATE_RULE_CATEGORIES);
  const [projects, setProjects] = useStateApp(PROJECTS_DATA);
  const [projectCats, setProjectCats] = useStateApp(PROJECT_CATEGORIES);
  const accent = accentOf();

  let body;
  if (nav === 'overview') body = <OverviewBody accent={accent} skills={skills} setSkills={setSkills} agents={agents} onNav={setNav} />;
  else if (nav === 'approvals') body = <ApprovalsBody accent={accent} />;
  else if (nav === 'gate-rules') body = <GateRulesBody accent={accent} gateRules={gateRules} setGateRules={setGateRules} agents={agents} skills={skills} cats={gateRuleCats} setCats={setGateRuleCats} />;
  else if (nav === 'skills') body = <SkillsBody accent={accent} skills={skills} setSkills={setSkills} cats={skillCats} setCats={setSkillCats} gateRules={gateRules} projects={projects} />;
  else if (nav === 'agents') body = <AgentsBody accent={accent} agents={agents} setAgents={setAgents} cats={agentCats} setCats={setAgentCats} gateRules={gateRules} projects={projects} />;
  else if (nav === 'pipelines') body = <PipelinesBody accent={accent} />;
  else if (nav === 'projects') body = <ProjectsBody accent={accent} projects={projects} setProjects={setProjects} cats={projectCats} setCats={setProjectCats} />;
  else if (nav === 'integrations') body = <IntegrationsBody accent={accent} />;
  else if (nav === 'automations') body = <AutomationsBody accent={accent} />;
  else if (nav === 'memory') body = <MemoryBody accent={accent} />;
  else if (nav === 'runs') body = <RunsBody accent={accent} />;
  else if (nav === 'settings') body = <SettingsBody accent={accent} settings={settings} saveSettings={saveSettings} />;
  else body = <Placeholder nav={nav} accent={accent} />;

  return (
    <Frame skin="velin">
      <Sidebar active={nav} accent={accent} onNav={setNav} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <TopBar accent={accent} nav={nav} lang={settings.lang} onLang={(v) => saveSettings({ lang: v })} />
        <div style={{ flex: 1, overflow: 'auto', position: 'relative', padding: '24px 26px' }}>
          {body}
        </div>
      </div>
    </Frame>
  );
}

Object.assign(window, { App });
