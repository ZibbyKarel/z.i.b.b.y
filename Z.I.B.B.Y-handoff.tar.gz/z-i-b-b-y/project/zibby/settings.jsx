// ZIBBY velín — Nastavení systému: předvolby (jazyk CZ/EN, výchozí kontext, caffeinate) + systém
const { useState: useStateSet } = React;

// i18n pro tuhle obrazovku — důkaz, že přepínač funguje (zbytek rozhraní se překládá postupně)
const SETTINGS_I18N = {
  cs: {
    title: 'Nastavení systému', sub: 'démon na', preferences: 'Předvolby',
    language: 'Jazyk rozhraní', languageHint: 'Plný překlad rozhraní se postupně dopisuje — zatím je dostupná čeština a angličtina.',
    defaultCtx: 'Výchozí kontext', defaultCtxHint: 'Kontext, ve kterém se velín otevře po spuštění.',
    caffeinate: 'Držet Mac vzhůru (caffeinate)', caffeinateHint: 'Nechá démona běžet i v noci pro naplánované běhy agentů.',
    system: 'Systém', daemon: 'Démon', host: 'Stroj', uptime: 'Uptime', status: 'Stav',
    nominal: 'NOMINAL · vzhůru', langNote: 'Vybráno: čeština',
  },
  en: {
    title: 'System settings', sub: 'daemon on', preferences: 'Preferences',
    language: 'Interface language', languageHint: 'Full interface translation is rolling out gradually — Czech and English are available for now.',
    defaultCtx: 'Default context', defaultCtxHint: 'The context the cockpit opens in on launch.',
    caffeinate: 'Keep Mac awake (caffeinate)', caffeinateHint: 'Keeps the daemon running overnight for scheduled agent runs.',
    system: 'System', daemon: 'Daemon', host: 'Host', uptime: 'Uptime', status: 'Status',
    nominal: 'NOMINAL · awake', langNote: 'Selected: English',
  },
};

// segmented control (velín styl)
const Segmented = ({ value, options, accent, onChange }) => (
  <div style={{ display: 'inline-flex', gap: 3, padding: 3, background: Z.bg0, border: `1px solid ${Z.line}`, borderRadius: 3 }}>
    {options.map((o) => {
      const on = value === o.id;
      return (
        <button key={o.id} onClick={() => onChange(o.id)} style={{
          fontFamily: Z.mono, fontSize: 12, fontWeight: 600, padding: '6px 14px', borderRadius: 2, border: 'none', cursor: 'pointer',
          color: on ? Z.bg0 : Z.inkDim, background: on ? accent : 'transparent',
          boxShadow: on ? `0 0 12px ${accent}55` : 'none', transition: 'all .15s',
        }}>{o.label}</button>
      );
    })}
  </div>
);

// toggle switch
const Switch = ({ on, accent, onToggle }) => (
  <button onClick={onToggle} title={on ? 'zapnuto' : 'vypnuto'} style={{
    width: 46, height: 26, borderRadius: 26, padding: 3, cursor: 'pointer', display: 'flex',
    justifyContent: on ? 'flex-end' : 'flex-start', alignItems: 'center',
    border: `1px solid ${on ? accent : Z.line}`, background: on ? `${accent}26` : Z.bg0,
    transition: 'all .15s',
  }}>
    <span style={{ width: 18, height: 18, borderRadius: '50%', background: on ? accent : Z.inkFaint, boxShadow: on ? `0 0 10px ${accent}88` : 'none', transition: 'all .15s' }} />
  </button>
);

const SettingRow = ({ label, hint, control, last }) => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 24, padding: '16px 0', borderBottom: last ? 'none' : `1px solid ${Z.line}` }}>
    <div style={{ minWidth: 0 }}>
      <div style={{ fontSize: 14, color: Z.ink, fontWeight: 500 }}>{label}</div>
      {hint && <Mono style={{ fontSize: 10.5, color: Z.inkFaint, display: 'block', marginTop: 5, lineHeight: 1.45, maxWidth: 460 }}>{hint}</Mono>}
    </div>
    <div style={{ flex: '0 0 auto' }}>{control}</div>
  </div>
);

const InfoRow = ({ label, value, valueColor, last }) => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, padding: '12px 0', borderBottom: last ? 'none' : `1px solid ${Z.line}` }}>
    <Mono style={{ fontSize: 11, color: Z.inkFaint, letterSpacing: '0.04em' }}>{label}</Mono>
    <Mono style={{ fontSize: 12, color: valueColor || Z.ink, fontWeight: 600 }}>{value}</Mono>
  </div>
);

const SettingsBody = ({ accent, settings, saveSettings }) => {
  const t = SETTINGS_I18N[settings.lang] || SETTINGS_I18N.cs;
  return (
    <div style={{ maxWidth: 880, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* header */}
      <HudPanel accent={accent} pad={20}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
          <div style={{ width: 42, height: 42, flex: '0 0 auto', borderRadius: 2, display: 'grid', placeItems: 'center', background: accentDimOf(), color: accent, border: `1px solid ${accent}44` }}>
            <Icon name="gear" size={21} />
          </div>
          <div>
            <div style={{ fontSize: 22, fontWeight: 600 }}>{t.title}</div>
            <Mono style={{ fontSize: 11, color: Z.inkDim, display: 'block', marginTop: 5 }}>{SYSTEM.daemon} · {t.sub} {SYSTEM.host}</Mono>
          </div>
        </div>
      </HudPanel>

      {/* preferences */}
      <HudPanel accent={accent} title={t.preferences} pad={20}>
        <SettingRow
          label={t.language}
          hint={t.languageHint}
          control={
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
              <Segmented value={settings.lang} accent={accent} onChange={(v) => saveSettings({ lang: v })}
                options={[{ id: 'cs', label: 'Čeština' }, { id: 'en', label: 'English' }]} />
              <Mono style={{ fontSize: 9, color: accent }}>{t.langNote}</Mono>
            </div>
          } />
        <SettingRow
          last
          label={t.caffeinate}
          hint={t.caffeinateHint}
          control={<Switch on={settings.caffeinate} accent={accent} onToggle={() => saveSettings({ caffeinate: !settings.caffeinate })} />} />
      </HudPanel>

      {/* system info */}
      <HudPanel accent={accent} title={t.system} pad={20}>
        <InfoRow label={t.daemon} value={SYSTEM.daemon} />
        <InfoRow label={t.host} value={SYSTEM.host} />
        <InfoRow label={t.uptime} value={SYSTEM.uptime} />
        <InfoRow last label={t.status} value={t.nominal} valueColor={Z.ok} />
      </HudPanel>
    </div>
  );
};

Object.assign(window, { SettingsBody, Segmented, Switch, SETTINGS_I18N });
