// ZIBBY velín — Overview body (content only; shell lives in app.jsx)
const { useState: useStateOv } = React;

// Prominentní blok jednoho interaktivního limitu (5h / týden)
const LimitBlock = ({ d }) => {
  const c = limitColor(d.usedPct);
  return (
    <div style={{ flex: '1 1 0', minWidth: 0, padding: '13px 14px', background: Z.bg0, border: `1px solid ${c}38`, borderRadius: 3, boxShadow: `0 0 0 1px ${c}14, 0 0 18px ${c}12` }}>
      <Mono style={{ fontSize: 10, color: Z.inkDim, letterSpacing: '0.06em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{d.label}</Mono>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 2, marginTop: 9 }}>
        <Mono style={{ fontSize: 28, fontWeight: 700, color: c, lineHeight: 1 }}>{d.usedPct}</Mono>
        <Mono style={{ fontSize: 14, fontWeight: 700, color: c }}>%</Mono>
      </div>
      <div style={{ marginTop: 10 }}><Bar pct={d.usedPct} color={c} h={7} glow /></div>
      <Mono style={{ fontSize: 8.5, color: Z.inkFaint, display: 'block', marginTop: 7, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>reset {d.resetIn}</Mono>
    </div>
  );
};

// Prominentní panel s limity pro dashboard — interaktivní limity jako hlavní prvek + SDK kredit
const LimitsPanel = ({ accent }) => {
  const r = CLAUDE_LIMITS.rolling, w = CLAUDE_LIMITS.weekly, sdk = AGENT_SDK, sdkC = limitColor(sdk.usedPct);
  return (
    <HudPanel accent={accent} title="claude · interaktivní limity" pad={18}
      right={<Mono style={{ fontSize: 9, color: Z.inkFaint }}>čerpá tvůj chat</Mono>}>
      <div style={{ display: 'flex', gap: 10 }}>
        <LimitBlock d={r} />
        <LimitBlock d={w} />
      </div>
      {/* Agent SDK kredit — sekundární strip */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 14, paddingTop: 14, borderTop: `1px solid ${Z.line}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, color: sdkC, flex: '0 0 auto' }}>
          <Icon name="dollar" size={16} />
          <Mono style={{ fontSize: 8.5, color: Z.inkFaint, letterSpacing: '0.08em', textTransform: 'uppercase', lineHeight: 1.2 }}>agent<br />sdk</Mono>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 6 }}>
            <Mono style={{ fontSize: 13, fontWeight: 700, color: Z.ink, whiteSpace: 'nowrap' }}>${sdk.remaining} <span style={{ fontSize: 10, color: Z.inkFaint, fontWeight: 400 }}>/ ${sdk.total}</span></Mono>
            <Mono style={{ fontSize: 9, color: Z.inkFaint }}>obnova {sdk.renew}</Mono>
          </div>
          <Bar pct={sdk.usedPct} color={sdkC} h={5} glow />
        </div>
      </div>
    </HudPanel>
  );
};

const OverviewBody = ({ accent, skills = SKILLS, setSkills, agents = AGENTS, onNav }) => {
  const [runSkill, setRunSkill] = useStateOv(null);
  const [down, setDown] = useStateOv(false); // simulace výpadku démona (klikni na stav)
  const sdk = AGENT_SDK, sdkC = limitColor(sdk.usedPct);
  const pinned = skills.filter((s) => s.pinned);
  const skillCount = skills.length;
  const agentCount = agents.length;
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) 360px', gap: 20, alignItems: 'start', maxWidth: 1400, margin: '0 auto' }}>
      {/* LEFT */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20, minWidth: 0 }}>
        {down ? (
          /* ---- VARIANTA: DÉMON NEBĚŽÍ ---- */
          <HudPanel accent={Z.bad} pad={22} style={{ borderColor: `${Z.bad}66`, boxShadow: `0 0 0 1px ${Z.bad}22, 0 0 26px ${Z.bad}1a` }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
              <div style={{ minWidth: 0 }}>
                <div onClick={() => setDown(false)} title="přepnout zpět na NOMINAL" style={{ display: 'flex', alignItems: 'center', gap: 9, cursor: 'pointer' }}>
                  <Dot color={Z.bad} pulse />
                  <Mono style={{ fontSize: 11, letterSpacing: '0.18em', color: Z.bad, textTransform: 'uppercase' }}>Systém · OFFLINE</Mono>
                  <Mono style={{ fontSize: 10, color: Z.inkFaint, marginLeft: 4 }}>· démon na {SYSTEM.host} neodpovídá</Mono>
                </div>
                <div style={{ fontSize: 27, fontWeight: 600, marginTop: 13, letterSpacing: '-0.01em', lineHeight: 1.2 }}>
                  Node démon spadl. <span style={{ color: Z.inkDim }}>Agenti jsou pozastavení,</span> naplánované běhy se nespustí.
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 12, padding: '9px 12px', background: `${Z.bad}12`, border: `1px solid ${Z.bad}33`, borderRadius: 3, maxWidth: 'fit-content' }}>
                  <Icon name="warn" size={14} style={{ color: Z.bad }} />
                  <Mono style={{ fontSize: 10.5, color: Z.inkDim }}>poslední signál před 4 m · zdvih ECONNREFUSED na :8787 · 3 běhy ve frontě</Mono>
                </div>
              </div>
              <button onClick={() => setDown(false)} style={{
                display: 'inline-flex', alignItems: 'center', gap: 8, fontFamily: Z.mono, fontSize: 12, fontWeight: 700,
                padding: '10px 16px', cursor: 'pointer', borderRadius: 2, color: Z.bg0, background: Z.bad, border: 'none',
                boxShadow: `0 0 16px ${Z.bad}66`, flex: '0 0 auto',
              }}><Icon name="retry" size={15} stroke={2} /> Restartovat démona</button>
            </div>
            <div style={{ display: 'flex', gap: 36, marginTop: 22, paddingTop: 18, borderTop: `1px solid ${Z.bad}33`, flexWrap: 'wrap', opacity: 0.55 }}>
              <Stat value="—" label="agenti" accent={Z.bad} icon="bot" />
              <Stat value={String(skillCount).padStart(2, '0')} label="skilly" accent={Z.inkDim} icon="spark" />
              <Stat value="—" label="pipeline" accent={Z.inkDim} icon="flow" />
              <Stat value="—" label="integrace" accent={Z.inkDim} icon="plug" />
              <Stat value="—" label="automatizace" accent={Z.inkDim} icon="clock" />
            </div>
          </HudPanel>
        ) : (
          /* ---- VARIANTA: NOMINAL ---- */
          <HudPanel accent={accent} pad={22}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16 }}>
              <div>
                <div onClick={() => setDown(true)} title="simulovat výpadek démona" style={{ display: 'flex', alignItems: 'center', gap: 9, cursor: 'pointer' }}>
                  <Dot color={Z.ok} pulse />
                  <Mono style={{ fontSize: 11, letterSpacing: '0.18em', color: Z.ok, textTransform: 'uppercase' }}>Systém · NOMINAL</Mono>
                  <Mono style={{ fontSize: 10, color: Z.inkFaint, marginLeft: 4 }}>· démon na {SYSTEM.host}{SYSTEM.awake ? ' · vzhůru' : ''}</Mono>
                </div>
                <div style={{ fontSize: 27, fontWeight: 600, marginTop: 13, letterSpacing: '-0.01em', lineHeight: 1.2 }}>
                  {greeting()}. <span style={{ color: Z.inkDim }}>2 agenti pracují,</span> 1 čeká na tebe.
                </div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 36, marginTop: 22, paddingTop: 18, borderTop: `1px solid ${Z.line}`, flexWrap: 'wrap' }}>
              <Stat value={String(agentCount).padStart(2, '0')} label="agenti" accent={accent} icon="bot" />
              <Stat value={String(skillCount).padStart(2, '0')} label="skilly" accent={Z.inkDim} icon="spark" />
              <Stat value={String(SYSTEM.pipelines).padStart(2, '0')} label="pipeline" accent={Z.inkDim} icon="flow" />
              <Stat value={String(SYSTEM.integrations).padStart(2, '0')} label="integrace" accent={Z.inkDim} icon="plug" />
              <Stat value={String(SYSTEM.automations).padStart(2, '0')} label="automatizace" accent={Z.inkDim} icon="clock" />
            </div>
          </HudPanel>
        )}

        {/* morning briefing */}
        <HudPanel accent={accent} title="co se stalo přes noc · ranní brífink" pad={18}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {[
              { c: Z.ok, icon: 'branch', t: 'Build Feature → hotovo', s: 'branch feat/search-filters čeká na review · $11.20 / $25' },
              { c: Z.warn, icon: 'pause', t: 'Build Feature → zaparkováno po 3 pokusech', s: 'Tester: flaky test v checkout-flow · čeká na ranní review' },
              { c: Z.bad, icon: 'shield', t: 'PR Guard → čeká na souhlas s push', s: 'git push origin feat/api-rate-limit · náhled diffu' },
            ].map((r, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '10px 12px', background: Z.bg0, border: `1px solid ${Z.line}`, borderRadius: 3 }}>
                <Icon name={r.icon} size={16} style={{ color: r.c }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12.5, color: Z.ink, fontWeight: 500 }}>{r.t}</div>
                  <Mono style={{ fontSize: 10, color: Z.inkFaint, display: 'block', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.s}</Mono>
                </div>
                <Icon name="chevron" size={14} style={{ color: Z.inkFaint }} />
              </div>
            ))}
          </div>
        </HudPanel>

        {/* quick launch */}
        <HudPanel accent={accent} title="rychlé spuštění" pad={18}
          right={<GhostBtn icon="spark" accent={accent} onClick={() => onNav && onNav('skills')}>Spravovat skilly</GhostBtn>}>
          {pinned.length > 0 ? (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {pinned.map((s) => <SkillTile key={s.id} skill={s} accent={accent} onRun={setRunSkill} hud />)}
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, padding: '22px 0', textAlign: 'center' }}>
              <Icon name="spark" size={22} style={{ color: Z.inkFaint }} />
              <Mono style={{ fontSize: 11.5, color: Z.inkDim, maxWidth: 280, lineHeight: 1.5 }}>Zatím nic připnuté. Připni skill v sekci <span style={{ color: accent }}>Skilly</span> a objeví se tady.</Mono>
              <GhostBtn icon="spark" accent={accent} onClick={() => onNav && onNav('skills')}>Otevřít Skilly</GhostBtn>
            </div>
          )}
        </HudPanel>
      </div>

      {/* RIGHT RAIL */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20, minWidth: 0 }}>
        <LimitsPanel accent={accent} />
        <div>
          <ApprovalCard hud />
          <div style={{ marginTop: 10, display: 'flex', justifyContent: 'flex-end' }}>
            <GhostBtn icon="shield" accent={Z.bad} onClick={() => onNav && onNav('approvals')}>Celá fronta schválení</GhostBtn>
          </div>
        </div>
        <HudPanel accent={accent} title="běžící agenti" pad={18}>
          {RUNNING_AGENTS.map((a) => <AgentRow key={a.id} a={a} hud />)}
          <div style={{ marginTop: 12 }}><GhostBtn icon="pulse" accent={accent} onClick={() => onNav && onNav('runs')}>Otevřít aktivitu</GhostBtn></div>
        </HudPanel>
      </div>

      <RunModal skill={runSkill} accent={accent} onClose={() => setRunSkill(null)} />
    </div>
  );
};

Object.assign(window, { OverviewBody });
